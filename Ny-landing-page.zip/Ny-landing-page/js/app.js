/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/
const sections = document.querySelectorAll('section');
const navList = document.getElementById('navbar__list');

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

/**
 * @description Create nav items
 * @param {String} name - The name displayed in the nav item
 * @param {String} id - The id of the section that the nav item links to
 */

function createNavItem(name, id) {
  const listItem = document.createElement('li');
  listItem.innerHTML = `<a class="menu__link" href="#${id}">${name}</a>`;
  navList.appendChild(listItem);
};

/**
 * @description Check if section is viewport
 * @param {HTMLElement} section - The section is to be checked
 * @returns {boolean} True if section is in viewport, false if not in viewpoint
 */
function isSectionInView(section) {
  const rect = section.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
};

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// Build the nav
function buildNav() {
  sections.forEach(section => {
    createNavItem(section.dataset.nav, section.id);
  });
};

// Add class 'active' to section when near top of viewport
function setActiveSection() {
  sections.forEach(section => {
    if (isSectionInView(section)) {
      section.classList.add('your-active-class');
    } else {
      section.classList.remove('your-active-class');
    }
  });
};

// Scroll to anchor ID using scrollTO event
function scrollToSection(event) {
  event.preventDefault();
  const targetId = event.target.getAttribute('href').substring(1);
  const targetSection = document.getElementById(targetId);
  window.scrollTo({
    top: targetSection.offsetTop,
    behavior: 'smooth'
  });
};

/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 
document.addEventListener('DOMContentLoaded', buildNav);

// Scroll to section on link click
navList.addEventListener('click', scrollToSection);

// Set sections as active
window.addEventListener('scroll', setActiveSection);



